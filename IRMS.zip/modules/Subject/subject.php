<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8" />
    <meta name="google" value="notranslate" />
    <link rel="icon" type="image/x-icon" href="../../assets/img/logo.png">
    <title>IRMS-SUBJECT</title>
    <link rel="stylesheet" type="text/css" href="../../assets/css/font-awesome-4.7.0/css/menu.css">
    <link rel="stylesheet" type="text/css" href="../../assets/css/font-awesome-4.7.0/css/style.css">
    <link rel="stylesheet" type="text/css" href="../../assets/css/font-awesome-4.7.0/css/font-awesome.min.css"
        rel="stylesheet">
    <!-- <script src="../../assets/js/table.js"></script> -->
    <script src="../../assets/js//jquery-3.7.0.js"></script>
    <script src="../../assets/js/jquery.dataTables.min.js"></script>
    <link rel="stylesheet" href="../../assets/css/jquery.dataTables.min.css">
</head>

<body>
    <?php 
$page = 'Subject';
include "../../navbar.php";
include "../../db_conn.php";
if (!isset($_GET['grade'])) {
    header("Location: ./");
    exit();
  } 
  $grade = $_GET['grade'];
 ?>
        <div class="content">
            <?php include "../../includes/alert.php"; ?>
            <div class="header">
                <h1><?php if ($page) {echo $page;} ?></h1>
            </div>
                        
<a href="./" class="back"><i class="fa fa-arrow-circle-o-left fa-2x"></i></a>
            
            <div class="search-box">
            <!-- <a href="./export.php"><button style="float:left;">Export</button></a> -->
                <a href="./add.php?grade=<?php echo $grade; ?>"><button>Add</button></a>
            </div>
            <div class="table_wrap">
            <table id="example" class="data list">
                <thead>
                    <th style="width: 60px;">ID</th>
                    <th>Subject Name</th>
                    <th>Subject Code</th>
                    <th>Grade Level</th>
                    <th>Assigned Teacher</th>
                    <th style="width: 55px;">Action</th>
                </thead>
                <?php
         $squery = mysqli_query($conn, "
         SELECT s.*, CONCAT(t.first_name, ' ', t.last_name) AS teacher_name 
         FROM subject s 
         LEFT JOIN teacher t ON s.teacher_id = t.id 
         WHERE s.del_status != 'deleted' AND s.grade_level = '$grade'
         ORDER BY s.id DESC;
     ");
     while ($row = mysqli_fetch_array($squery)) {
        ?>
                <tr class="table-row">
                    <td><?php echo $row['id'] ?></td>
                    <td><?php echo $row['name'] ?></td>
                    <td><?php echo $row['code'] ?></td>
                    <td>Grade <?php echo $row['grade_level'] ?></td>
                    <td><?php echo $row['teacher_name'] ?></td>
                    <td>
                        <a class="view" href="edit.php?id=<?php echo $row['id'] ?>">
                        View
                        </a>
                        <!-- <a href=""><i class="fa fa-trash fa-lg" aria-hidden="true"></i></a> -->
                    </td>
                </tr>
                <?php }?>
            </table>
            </div>
    </div>
<script>new DataTable('#example', {
    order: [[0, 'desc']]
});</script>

</body>

</html>