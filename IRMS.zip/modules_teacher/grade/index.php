
<?php $page = 'Grades';?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="google" value="notranslate" />
    <title>IRMS-<?php if ($page) {echo $page;} ?></title>
    <link rel="icon" type="image/x-icon" href="../../assets/img/logo.png">
    <link rel="stylesheet" type="text/css" href="../../assets/css/font-awesome-4.7.0/css/menu.css">
    <link rel="stylesheet" type="text/css" href="../../assets/css/font-awesome-4.7.0/css/style.css">
    <link rel="stylesheet" type="text/css" href="../../assets/css/font-awesome-4.7.0/css/font-awesome.min.css">
</head>
<body>
<?php include "../../navbar_teacher.php"; ?>
<?php 


// Fetch sections where the teacher teaches a subject
$query = "SELECT s.id AS section_id, s.name AS section_name, s.grade_level, sub.name AS subject_name
    FROM section_subject ss
    JOIN scheduler sch ON ss.subject = sch.subject AND ss.section = sch.section
    JOIN section s ON ss.section = s.id
    JOIN subject sub ON sub.id = ss.subject
    WHERE ss.teacher = '$teacher_id'
    GROUP BY s.id
";

// $stmt = $conn->prepare($query);
// $stmt->execute();
// $result = $stmt->get_result();
include "../../db_conn.php";
$squery = mysqli_query($conn,$query);


?>
<div class="content">
    <div class="header">
        <h1><?php if ($page) {echo $page;} ?></h1>
    </div>

    <div  class="row g-3">
    <div class="grid-container-dashboard">
            <?php while ($row = mysqli_fetch_array($squery)): ?>
                <a href="./subject.php?section_id=<?= $row['section_id'] ?>" class="schedule" style="width: max-content;">
                    <div class="box-icon"><i class="fa fa-users"></i></div>Section :  <?= $row['section_name'] ?><br> Grade: <?= $row['grade_level'] ?> 
                </a>
            <?php endwhile; ?>
        </div>
    </div>
</div>
</body>
</html>
